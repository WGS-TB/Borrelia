#!/bin/bash
git pull
make
