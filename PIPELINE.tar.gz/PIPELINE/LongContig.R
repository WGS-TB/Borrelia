FindLength <- function(p){
  i=16
  print(p)
  s=""
  while(substring(p,i,i)!='_'){
      print (substring(p,i,i))
    s<-paste(s,substring(p,i,i),sep="")
    i<-i+1
  }
  x<-strtoi(s)
  return(x)
}

#library("pracma")

args <- commandArgs(trailingOnly = TRUE)
fileNameF<-args[1]

adr<-paste(fileNameF,'contigs.fa',sep="")
  
  
  
  
  
  
  lens<-0
  lens_line<-0
  l<-1
  sss<-try(conn <- file(adr,open="r") )
  if(!inherits(sss,'try-error') ){
    contigs <-readLines(conn)
    for (k in 1:length(contigs)) 
    {
      if (substring(contigs[k],1,1)==">" ) {
        lens[l]<-FindLength(contigs[k])
        lens_line[l]<-k
        l<-l+1
      }
      
    }
    max_index<-which(lens==max(lens))
    
    
    if(max_index != (l-1) ){
      LContg<-contigs[lens_line[max_index]:(lens_line[max_index+1]-1)]
    }
    else{
      LContg<-contigs[lens_line[max_index]:length(contigs)]
    }
    
    
    
    fileName<-paste(fileNameF,'Longestcontigs.fa',sep="")
    
    fileConn<-file(fileName)
    Q<-paste(LContg,sep=" ")
    writeLines(Q,fileConn )
    close(fileConn)     
    
    close(conn)      
  }
  
