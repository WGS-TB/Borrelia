#!/bin/bash


////////////////////////////////////////////////////////////

 b='cookiecutter make_library -i Ref_Alleles.fa -o all_19.txt -l 19'
   eval $b


///////////////////////////////////////////////////////////////
directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata

IFS=$'\n' read -d '' -r -a names < $directory_rawdata
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   b=${names[$i]} 
   
    
    
   dir2="$1$b/zztable"
   echo $dir2
   ls "$1$b" > $dir2


   readarray names_f < $dir2
   IFS=$'\n' read -d '' -r -a names_f < $dir2 
   n1len=${#names_f[@]}-1


  
  for (( j=0; j<${n1len}; j=j+2 ));
   do
   
      
	
  
          q="cookiecutter extract -i $1$b/${names_f[$j]}  $1$b/${names_f[$j+1]}  -f all_19.txt -o Filtered/$b"
      eval $q
   done
done
##################################################################################################
#!/bin/bash


////////////////////////////////////////////////////////////
directory_rawdata="Filtered/zztable.txt"

#$1 is the directory of the input folder 
ls Filtered/ > $directory_rawdata
IFS=$'\n' read -d '' -r -a names < $directory_rawdata
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   b=${names[$i]} 
   
    mkdir -p RESULT/$b/ 
   
done

for (( i=0; i<${nlen}; i++ ));
do

   b=${names[$i]} 
   
    
    
   dir2="Filtered/$b/zztable"
   echo $dir2
   ls "Filtered/$b" > $dir2


  
    IFS=$'\n' read -d '' -r -a names_f < $dir2
   n1len=${#names_f[@]}-1


  
 
   j=0
      
	
  
          q="Rscript sameread.R Filtered/$b/${names_f[$j]}  Filtered/$b/${names_f[$j+1]} RESULT/$b/${names_f[$j]} RESULT/$b/${names_f[$j+1]}"
      eval $q

done

rm -r "Filtered/"
########################################################################################################



#////////////////////////////////////////////////////////////
directory_rawdata="RESULT/zztable.txt"
ls RESULT/ > $directory_rawdata
IFS=$'\n' read -d '' -r -a names < $directory_rawdata
nlen=${#names[@]}-1

echo $nlen
for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   #b=${a:0:$len}
    
    
   dir2="RESULT/$a/zztable"
   echo $dir2


   ls "RESULT/$a" > $dir2


 
         IFS=$'\n' read -d '' -r -a names_f < $dir2 

   n1len=${#names_f[@]}-1


  
 
   j=0
      
	 q="Rscript --vanilla Wrapper.R RESULT/$a/${names_f[$j]}  RESULT/$a/${names_f[$j+1]} $2 RESULT/$a/leftOver"
        eval $q

  
  

done




#/////////////////////////////////////////////////////////////
directory_rawdata="RESULT/zztable.txt"



IFS=$'\n' read -d '' -r -a names < $directory_rawdata
nlen=${#names[@]}-1


for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 

    
    
   dir2="RESULT/$a/leftOver/zztable"
   echo $dir2
   ls "RESULT/$a/leftOver" > $dir2


  
    IFS=$'\n' read -d '' -r -a names_c < $dir2
   n1len=${#names_c[@]}-1


  
   j=0

   q="./interleave_fastq.sh RESULT/$a/leftOver/${names_c[$j]}  RESULT/$a/leftOver/${names_c[$j+1]}  > RESULT/$a/leftOver/interleave"
   eval $q
   

  q="VelvetOptimiser.pl --d RESULT/$a/leftOver/Results/assembly_result -s 31 -e 51 --k 'n50' --c 'tbp' --f '-fastq -shortPaired RESULT/$a/leftOver/interleave' "
eval $q

   q="Rscript LongContig.R RESULT/$a/leftOver/Results/assembly_result/"
  eval $q
  

done








