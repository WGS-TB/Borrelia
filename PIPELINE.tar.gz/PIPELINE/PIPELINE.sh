#!/bin/bash



#////////////////////////////////////////////////////////////
directory_rawdata="$1zztable.txt"
ls $1 > $directory_rawdata
IFS=$'\n' read -d '' -r -a names < $directory_rawdata
nlen=${#names[@]}-1

echo $nlen
for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   #b=${a:0:$len}
    
    
   dir2="$1$a/zztable"
   echo $dir2


   ls "$1$a" > $dir2


 
         IFS=$'\n' read -d '' -r -a names_f < $dir2 

   n1len=${#names_f[@]}-1


  
 
   j=0
      
	 q="Rscript --vanilla Wrapper.R $1$a/${names_f[$j]}  $1$a/${names_f[$j+1]} $2 $1$a/leftOver"
        eval $q

  
  

done




#/////////////////////////////////////////////////////////////
#directory_rawdata="$1zztable.txt"



IFS=$'\n' read -d '' -r -a names < $directory_rawdata
nlen=${#names[@]}-1


for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 

    
    
   dir2="$1$a/leftOver/zztable"
   echo $dir2
   ls "$1$a/leftOver" > $dir2


  
    IFS=$'\n' read -d '' -r -a names_c < $dir2
   n1len=${#names_c[@]}-1


  
   j=0

   q="./interleave_fastq.sh $1$a/leftOver/${names_c[$j]}  $1$a/leftOver/${names_c[$j+1]}  > $1$a/leftOver/interleave"
   eval $q
   

  q="VelvetOptimiser.pl --d $1$a/leftOver/Results/assembly_result -s 31 -e 51 --k 'n50' --c 'tbp' --f '-fastq -shortPaired $1$a/leftOver/interleave' "
eval $q

   q="Rscript LongContig.R $1$a/leftOver/Results/assembly_result/"
  eval $q
  

done


