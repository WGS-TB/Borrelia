#!/bin/bash

directory="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory




readarray names < $directory
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
    
  
    
       ./GetAlignScore.sh /home/ali/Desktop/reference_Name/ $1$b/leftOver/Results/assembly_result/Longestcontigs.fa $1$b/leftOver/Results/assembly_result/AlignScoreRef.fa 
    

     ./GetAlignScore.sh /home/ali/Desktop/reference_RC/ $1$b/leftOver/Results/assembly_result/Longestcontigs.fa $1$b/leftOver/Results/assembly_result/AlignScoreRef_RC.fa
     
done


