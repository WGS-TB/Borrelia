#!/bin/bash

cd /home/ali/Desktop/Borrelia-codes/sratoolkit.2.7.0-ubuntu64/bin

readarray names < $1
nlen=${#names[@]}-1

for (( i=4; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
   echo $b
   q="./fastq-dump --split-3 $b -O /home/ali/Desktop/SRRdata/S$i"
   eval $q
   echo $q

done
