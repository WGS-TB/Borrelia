#!/bin/bash


////////////////////////////////////////////////////////////
directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    mkdir -p /home/ali/Desktop/cut2_output_k15_NSread/$b/ 
   
done

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
    
   dir2="$1$b/zztable"
   echo $dir2
   ls "$1$b" > $dir2


   readarray names_f < $dir2
    
   n1len=${#names_f[@]}-1


  
 
   j=0
      
	
  
          q="Rscript sameread.R $1$b/${names_f[$j]}  $1$b/${names_f[$j+1]} /home/ali/Desktop/cut2_output_k15_NSread/$b/${names_f[$j]} /home/ali/Desktop/cut2_output_k15_NSread/$b/${names_f[$j+1]}"
      eval $q

done




