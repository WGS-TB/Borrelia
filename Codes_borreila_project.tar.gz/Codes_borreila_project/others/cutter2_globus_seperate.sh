#!/bin/bash


////////////////////////////////////////////////////////////
directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1
echo $directory_rawdata

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
   echo $b
    mkdir -p /home/ali/Desktop/cut2_output_k19_globus/$b/ 
   
done

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
    
   dir2="$1$b/zztable"
  # echo $dir2
   ls "$1$b" > $dir2


   readarray names_f < $dir2
    
   n1len=${#names_f[@]}-1
echo ${n1len}

  half_len=$((n1len/2))
  echo $half_len
   for (( j=0; j<$half_len; j=j+1 ));
   do
       h_index=$((j+ half_len))
     echo  "$1$b/${names_f[$j]}"	
     echo  "$1$b/${names_f[$h_index]}"
          q="Rscript sameread_globusid.R $1$b/${names_f[$j]}  $1$b/${names_f[$h_index]} /home/ali/Desktop/cut2_output_k19_globus/$b/${names_f[$j]} /home/ali/Desktop/cut2_output_k19_globus/$b/${names_f[$h_index]}"
    eval $q

   done
done




