
#!/bin/bash



directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}




cat $1$b $2 > $3

cd /home/ali/Desktop/needleman_wunsch-0.3.5
  echo $b
 q="./needleman_wunsch --printscores --colour  --freestartgap --freeendgap --file $3"
 eval $q 
  
  
done
