
#!/bin/bash



directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
   ls $1$b > "$1$b/zztable.txt"
   readarray names_f <"$1$b/zztable.txt"
   nlen=${#names_f[@]}-1
  for (( j=0; j<${nlen}; j++ ));
  do 

   a_f=${names_f[$j]} 
   b_f=${a_f:0:$len-1}
   
   q="samtools view -S  $1$b/$b_f >> $1$b/aaaa.txt"
   echo $q
 
   eval $q 
  
 done 
done
