#setwd("C:/Users/asafari.ADSFU/Desktop/Temp")

fnl.mat <- data.frame(CSV = NA,Var1 = NA,Freq = NA)
Result<- data.frame()

# i = 1
zztable<-readLines("/home/ali/Desktop/csv-globus/zztable.txt")
num_sample<-length(zztable)-1
for (k in 1: (length(zztable)-1) ) {
 # print(zztable[k])

  mat.tem <- read.csv(paste("/home/ali/Desktop/csv-globus/",zztable[k], sep = ""))
  
  
  
  fnl.mat <- rbind(fnl.mat, cbind(CSV = zztable[k], mat.tem))
  

}
fnl.mat <- fnl.mat[-1, ]

ref_names<-unique(fnl.mat$Var1)
Freq_refs<-table(fnl.mat$Var1)

for (i in 1:(length(ref_names)-1) ) {
  for (j in (i+1):length(ref_names) ) {
   # print(paste (ref_names[i],"vs",ref_names[j]) )
       num<-0
      for (k in 1:(length(zztable)-1)) {
        if( (ref_names[i] %in% fnl.mat$Var1[fnl.mat$CSV == zztable[k]]) & (ref_names[j] %in% fnl.mat$Var1[fnl.mat$CSV == zztable[k]]) )
        {
          num<-num+1
        }
      }
      Result[ref_names[i],ref_names[j]]<-num 
      Result[ref_names[j],ref_names[i]]<-num 
  }
  
}

#("K" %in% fnl.mat$Var1[fnl.mat$CSV == 2]) & ("Ua" %in% fnl.mat$Var1[fnl.mat$CSV == 2])

A<-"B"
B<-"A"
A_B<-Result[B,A]
A_notB<-Freq_refs[A]-Result[B,A]
B_notA<-Freq_refs[B]-Result[B,A]
notAB<-num_sample+Result[B,A]-Freq_refs[A]-Freq_refs[B]

challenge.df <-matrix(c(A_B,B_notA,A_notB,notAB), nrow = 2,dimnames =list(c("A", "not_A"),c("B", "not_B")))
Fish_result<-fisher.test(challenge.df)


