Findnum <- function(p){
  # print(p)
  i<-nchar(p)
  s=""
  while(substring(p,i,i)!=' '){
    #print (substring(p,i,i))
    s<-paste(substring(p,i,i),s,sep="")
    i<-i-1
  }
  x<-strtoi(s)
  return(x)
}

#
library("pracma")
#args <- commandArgs(trailingOnly = TRUE)
#adres1<-args[1]
zztable<-readLines( paste("/home/ali/Desktop/Result_globus/","zztable.txt",sep="") )
for (j in 1:length(zztable)) {
  
if(file.exists(paste("/home/ali/Desktop/Result_globus/",zztable[j],"/leftOver/Results/assembly_result/AlignScoreRef.fa",sep=""))==TRUE)
{  
table_score<-readLines(paste("/home/ali/Desktop/Result_globus/",zztable[j],"/leftOver/Results/assembly_result/AlignScoreRef.fa",sep=""))
table_score_RC<-readLines(paste("/home/ali/Desktop/Result_globus/",zztable[j],"/leftOver/Results/assembly_result/AlignScoreRef_RC.fa",sep=""))
length<-length(table_score)-2
#####################################
max_score_val<- -1000
max_score_name<-"Nothing"
for (i in seq(1,length,3)) {
   print(table_score[i+1])
   print(table_score[i])
   sc_val<-Findnum(table_score[i+1])  
   if (sc_val > max_score_val) {
     max_score_val<-sc_val
     max_score_name<-table_score[i]
   }
   print(sc_val)
}

for (i in seq(1,length,3)) {
  print(table_score_RC[i+1])
  print(table_score_RC[i])
  sc_val<-Findnum(table_score_RC[i+1])  
  if (sc_val > max_score_val) {
    max_score_val<-sc_val
    max_score_name<-table_score[i]
  }
  print(sc_val)
}
contig<-readLines(paste("/home/ali/Desktop/Result_globus/",zztable[j],"/leftOver/Results/assembly_result/Longestcontigs.fa",sep=""))
#fileName<-args[3]
#fileName<-"/home/ali/Desktop/bb/BEP-6//leftOver/Results/assembly_result/UsedReads.fa"
#fileConn<-file(fileName)
write(zztable[j],"/home/ali/Desktop/summary_contig_report.txt",append='True')
write(contig[1],"/home/ali/Desktop/summary_contig_report.txt",append='True')
write(max_score_name,"/home/ali/Desktop/summary_contig_report.txt",append='True')
write(max_score_val,"/home/ali/Desktop/summary_contig_report.txt",append='True')
write('\n',"/home/ali/Desktop/summary_contig_report.txt",append='True')

}
}