Findnum <- function(p){
  
  # print(p)
  i<-nchar(p)
  i<-i-1
  s=""
  while(substring(p,i,i)!='*'){
    print (substring(p,i,i))
    s<-paste(substring(p,i,i),s,sep="")
    i<-i-1
  }
  x<-strtoi(s)
  return(x)
}
#files contains contings 
library("pracma")
adres1<-"Desktop/Result_globus/zztable.txt"
conn1 <- file(adres1,open="r")

str1 <-readLines(conn1)

length1<-length(str1)


list<-0
k<-1

for (i in 2:length1-1) {
  
  a<-paste("Desktop/Result_globus/",str1[i],'/leftOver/Results/assembly_result',sep = "")
  print(a)
  print(str1[i])
  b<-file.exists(a)
  print(b)
  if (b==TRUE){
    
    list[k]<-str1[i]
    k<-k+1
  }
}
filConn<-file("Desktop/Result_globus/Yes_contig")
writeLines(list,filConn )
close(filConn) 
close(conn1) 
