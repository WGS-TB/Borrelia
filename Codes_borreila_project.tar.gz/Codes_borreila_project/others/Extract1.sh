#!/bin/bash



#!/bin/bash

####extract and merge
################################################EXTRACT FILES

directory="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory




readarray names < $directory
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
    
   dir2="$1$b/zztable"
   echo $dir2
   ls "$1$b" > $dir2
    echo $i 

   readarray names_f < $dir2
    
   n1len=${#names_f[@]}-1


  
   for (( j=0; j<${n1len}; j++ ));
   do
    echo $j
   q="gzip -d  $1$b/${names_f[$j]}"
   echo $q
    eval $q
   done

done
