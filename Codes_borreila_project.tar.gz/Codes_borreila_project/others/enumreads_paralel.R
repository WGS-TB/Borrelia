library("pracma")
#args <- commandArgs(trailingOnly = TRUE)
adres1<-"/home/ali/Desktop/enum.fastq"
#adres1<-args[1]
conn1 <- file(adres1,open="r")

str1 <-readLines(conn1)
close(conn1)

length1<-length(str1)/4
length1<-length1-1
foreach(i= 0:length1) %do%  str1[(4*i+1)]<-paste(str1[(4*i+1)],"*",i,"*",sep="") 
fileName<-"/home/ali/Desktop/enum.fastq"
#fileName<-args[1]
fileConn<-file(fileName)
Q<-paste(str1,sep=" ")
writeLines(str1,fileConn )
close(fileConn)
