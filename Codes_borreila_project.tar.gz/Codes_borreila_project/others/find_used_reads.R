Findnum <- function(p){
  k<-0
  i<-0
  s<-""
  while(k!=1)
  {
    if(substring(p,i,i)=='_')
      k<-k+1
    i<-i+1
  }
  while(substring(p,i,i)!='_'){
    # print (substring(p,i,i))
    s<-paste(s,substring(p,i,i),sep="")
    i<-i+1
  }
  
  x<-strtoi(s)
  return(x)
}

# arg1 : adress of UnusedReads.fa
#agr2:  adress of interleave reads file
#arg3:  adress of out put 
library("pracma")
#args <- commandArgs(trailingOnly = TRUE)
#adres1<-args[1]
adres1<-"/home/ali/Desktop/bb/BEP-6//leftOver/Results/assembly_result/UnusedReads.fa"
conn1 <- file(adres1,open="r")
unused <-readLines(conn1)
length<-length(unused)-2
#####################################
adres2<-"/home/ali/Desktop/bb/BEP-6//leftOver/interleave"
conn2<-file(adres2,open="r")
seque <-readLines(conn2)

close(conn1)
close(conn2)
balance<-0
for (i in seq(1,length,3)) {
  
    if (substring(unused[i],1,1)==">") {
    
      z<-Findnum(unused[i])
      z<-z-balance
      l_ind<-(z*4)-3
      h_ind<-l_ind+3
      print((z*4)-3)
      seque<-seque[-(l_ind:h_ind)]
      balance<-balance+1
    }
  
}
#fileName<-args[3]
fileName<-"/home/ali/Desktop/bb/BEP-6//leftOver/Results/assembly_result/UsedReads.fa"
fileConn<-file(fileName)
writeLines(seque,fileConn )
close(fileConn)  