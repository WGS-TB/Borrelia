Findnum <- function(p){
  k<-0
  i<-0
  s<-""
  while(k!=3)
  {
    if(substring(p,i,i)==':')
        k<-k+1
    i<-i+1
  }
  while(substring(p,i,i)!=' '){
   # print (substring(p,i,i))
    s<-paste(s,substring(p,i,i),sep="")
    i<-i+1
  }
  
  
  return(s)
}

library("pracma")
args <- commandArgs(trailingOnly = TRUE)
adres1<-args[1]
adres2<-args[2]
conn1 <- file(adres1,open="r")
conn2 <- file(adres2,open="r")
str1 <-readLines(conn1)
str2 <-readLines(conn2)

length1<-length(str1)-2
length2<-length(str2)-2
Lread<-0
Rread<-0
i<-1
j<-1
k<-1

for (i in seq(1,length1,4) ) {
  for (j in seq(1,length2,4) ) {
    if(as.character(Findnum(str1[i])) == as.character(Findnum(str2[j])) ){
      Lread[k:(k+3)]<-str1[i:(i+3)]
      Rread[k:(k+3)]<-str2[j:(j+3)]
      k<-k+4
      
    #  print(str1[i])
     # print(str2[j])
      #print("AAAAAAAAA")
    
    }
  }
  
}

fileName<-args[3]
fileConn<-file(fileName)
Q<-paste(Lread,sep=" ")
writeLines(Q,fileConn )
close(fileConn)  
fileName<-args[4]
fileConn<-file(fileName)
Q<-paste(Rread,sep=" ")
writeLines(Q,fileConn )
close(fileConn)
close(conn1)
close(conn2)