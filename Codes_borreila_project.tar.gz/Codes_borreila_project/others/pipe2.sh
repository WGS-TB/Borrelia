#!/bin/bash


////////////////////////////////////////////////////////////
directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1




/////////////////////////////////////////////////////////////


for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
    
   dir2="$1$b/leftOver/zztable"
   echo $dir2
   ls "$1$b/leftOver" > $dir2


   readarray names_c < $dir2
    
   n1len=${#names_c[@]}-1


  
   j=0

   q="./interleave_fastq.sh $1$b/leftOver/${names_c[$j]}  $1$b/leftOver/${names_c[$j+1]}  > $1$b/leftOver/interleave"
   eval $q
   

  q="VelvetOptimiser.pl --d $1$b/leftOver/ZResults/assembly_result -s 31 -e 51 --k 'n50' --c 'tbp' --f '-fastq -shortPaired $1$b/leftOver/interleave' "
  eval $q

   q="Rscript LongContig.R $1$b/leftOver/ZResults/assembly_result/"
   eval $q
  

done


