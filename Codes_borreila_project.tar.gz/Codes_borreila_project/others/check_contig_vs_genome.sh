
#!/bin/bash

################ $2 dir of contig  $1 directory of sequences

directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
#ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1

dir_contig="$2List_contigs"
readarray names_f < $dir_contig
nlen_f=${#names_f[@]}-1


for (( j=0; j<${nlen}; j++ ));
do
    a_f=${names_f[$j]} 
    b_f=${a_f:0:$len-1}
    mkdir "/home/ali/Desktop/sam_output/$b_f/"
for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}

  #q="bwa index $1$b"
  #echo $q
  #eval $q
 q="bwa mem $1$b $2$b_f/leftOver/Results/assembly_result/Longestcontigs.fa >/home/ali/Desktop/sam_output/$b_f/$b.sam"
 echo $q
 
 eval $q 
  
 
done 
done
