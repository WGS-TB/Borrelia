
#!/bin/bash



directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}

 
 q="samtools flagstat $1$b"
 echo $q
 
 eval $q 
  
  
done
