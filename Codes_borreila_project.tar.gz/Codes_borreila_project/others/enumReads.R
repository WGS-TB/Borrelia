
library("pracma")
args <- commandArgs(trailingOnly = TRUE)
#adres1<-"/home/ali/Desktop/enum.fastq"
adres1<-args[1]
conn1 <- file(adres1,open="r")

str1 <-readLines(conn1)
close(conn1)

length1<-length(str1)-3

i<-1
j<-1
while (i<=length1){

  str1[i]<-paste(str1[i],"*",j,"*",sep="")
  j<-j+1
  i<-i+4
}
#fileName<-"/home/ali/Desktop/enum.fastq"
fileName<-args[1]
fileConn<-file(fileName)
Q<-paste(str1,sep=" ")
writeLines(str1,fileConn )
close(fileConn)
