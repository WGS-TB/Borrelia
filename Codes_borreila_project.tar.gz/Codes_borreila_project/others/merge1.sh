directory="$1zztable.txt"

#$1 is the directory of the input folder 
ls $1 > $directory




readarray names < $directory
nlen=${#names[@]}-1

################################################# MERGE FIELS 
for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
    
   dir2="$1$b/zztable"
   echo $dir2
   ls "$1$b" > $dir2
    echo $i 

   readarray names_f < $dir2
    
   n1len=${#names_f[@]}-1

   
     
  
	 cat $1$b/*R1_*.fastq > $1$b/$b.R1.fastq	
	
 
	 cat $1$b/*R2_*.fastq >  $1$b/$b.R2.fastq
	
     rm -r $1$b/*R1_*.fastq
     rm -r $1$b/*R2_*.fastq
done

