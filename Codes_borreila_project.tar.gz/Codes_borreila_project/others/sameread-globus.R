Findnum <- function(p){
 
  # print(p)
  i<-nchar(p)
  i<-i-1
  s=""
  while(substring(p,i,i)!='*'){
      print (substring(p,i,i))
    s<-paste(substring(p,i,i),s,sep="")
    i<-i-1
  }
  x<-strtoi(s)
  return(x)
}

library("pracma")
args <- commandArgs(trailingOnly = TRUE)
adres1<-args[1]
adres2<-args[2]
conn1 <- file(adres1,open="r")
conn2 <- file(adres2,open="r")
str1 <-readLines(conn1)
str2 <-readLines(conn2)

length1<-length(str1)-2
length2<-length(str2)-2
Lread<-0
Rread<-0
i<-1
j<-1
k<-1
while (i<length1 && j<length2){
  # print(Findnum(str1[i]))
  #print(Findnum(str2[i]))
  #print("AAAAAAAAAAAAAAA")
  if(Findnum(str1[i]) == Findnum(str2[j]) )
  {
    
    Lread[k:(k+3)]<-str1[i:(i+3)]
    Rread[k:(k+3)]<-str2[j:(j+3)]
    k<-k+4
    
    print(str1[i])
    print(str2[j])
    print("AAAAAAAAA")
    i<-i+4
    j<j+4
  }
  else if(Findnum(str1[i]) < Findnum(str2[j]) )  
  {
    i<-i+4
  }
  else{
    
    j<-j+4
  }  
  
  #print(i)
  #print(j)
}
fileName<-args[3]
fileConn<-file(fileName)
Q<-paste(Lread,sep=" ")
writeLines(Q,fileConn )
close(fileConn)  
fileName<-args[4]
fileConn<-file(fileName)
Q<-paste(Rread,sep=" ")
writeLines(Q,fileConn )
close(fileConn)
close(conn1)
close(conn2)