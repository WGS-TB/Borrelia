
#!/bin/bash



#directory_rawdata="$1zztable.txt"

#$1 is the directory of the input folder 
#ls $1 > $directory_rawdata
#readarray names < $directory_rawdata
#nlen=${#names[@]}-1


 
cat /home/ali/Desktop/Result_globus/$1/leftOver/Results/assembly_result/Longestcontigs.fa /home/ali/Desktop/reference_Name/$2 > /home/ali/Desktop/merged_conting.fa

cd /home/ali/Desktop/needleman_wunsch-0.3.5
 
 q="./needleman_wunsch --printscores --colour  --freestartgap  --file /home/ali/Desktop/merged_conting.fa "
 eval $q 
  
  

