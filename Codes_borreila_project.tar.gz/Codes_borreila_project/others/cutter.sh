#!/bin/bash


////////////////////////////////////////////////////////////
directory_rawdata="$1table.txt"

#$1 is the directory of the input folder 
ls $1 > $directory_rawdata
readarray names < $directory_rawdata
nlen=${#names[@]}-1

for (( i=0; i<${nlen}; i++ ));
do

   a=${names[$i]} 
   b=${a:0:$len-1}
    
    
   dir2="$1$b/zztable"
   echo $dir2
   ls "$1$b" > $dir2


   readarray names_f < $dir2
    
   n1len=${#names_f[@]}-1


  
  for (( j=0; j<${n1len}; j=j+2 ));
   do
   
      
	
  
          q="cookiecutter extract -i $1$b/${names_f[$j]}  $1$b/${names_f[$j+1]}  -f /home/ali/Desktop/Borrelia-codes/read-data-cooki/all_19.txt -o /home/ali/Desktop/cut_output_k19_globus/$b"
      eval $q
   done
done




