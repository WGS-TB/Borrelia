#include "version.h"

void show_version()
{
	std::cerr << "Version: " << version << std::endl;
}

