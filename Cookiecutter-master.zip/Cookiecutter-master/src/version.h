#include <iostream>
#include <string>

static const std::string version = "1.0.0";

void show_version();

